import React from 'react';

const WeatherCard = ({ weather }) => {
    if (!weather) {
        return <div className="weather-card">Loading...</div>;
    }

    const {
        city,
        country,
        temperature,
        description,
        icon,
        humidity,
        windSpeed
    } = weather;

    return (
        <div className="weather-card">
            <h2>{city}, {country}</h2>
            <img src={icon} alt={description} />
            <p>{description}</p>
            <p>Temperature: {temperature}°C</p>
            <p>Humidity: {humidity}%</p>
            <p>Wind Speed: {windSpeed} m/s</p>
        </div>
    );
};

export default WeatherCard;
