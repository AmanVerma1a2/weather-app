import React, { useState, useEffect } from 'react';
import axios from 'axios';
import SearchBar from './components/SearchBar';
import WeatherCard from './components/WeatherCard';
import './styles.css';

const App = () => {
    const [weather, setWeather] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [city, setCity] = useState(''); 

    const fetchWeather = async (city) => {
        setLoading(true);
        setError('');

        try {
            const apiKey = '8fe07664be0f95a0f02e561324100f92'; 
            const response = await axios.get('https://api.openweathermap.org/data/2.5/weather', {
                params: {
                    q: city,
                    appid: apiKey,
                    units: 'metric'
                }
            });

            const {
                main: { temp, feels_like, temp_min, temp_max, pressure, humidity },
                weather: [{ description, icon }],
                wind: { speed, deg, gust },
                clouds: { all: cloudCover },
                sys: { country, sunrise, sunset },
                name,
                timezone
            } = response.data;

            const weatherData = {
                temperature: temp,
                feelsLike: feels_like,
                tempMin: temp_min,
                tempMax: temp_max,
                pressure,
                humidity,
                description,
                icon: `http://openweathermap.org/img/wn/${icon}@2x.png`,
                windSpeed: speed,
                windDirection: deg,
                windGust: gust,
                cloudCover,
                country,
                sunrise,
                sunset,
                city: name,
                timezone
            };

            setWeather(weatherData);
        } catch (error) {
            setError('Failed to fetch weather data');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        let timer;

        if (city) {
            fetchWeather(city);

            timer = setInterval(() => {
                fetchWeather(city);
            }, 600000); 
        }

        return () => {
            if (timer) {
                clearInterval(timer);
            }
        };
    }, [city]);

    return (
        <div className="app">
            <h1>Real-Time Weather Dashboard</h1>
            <SearchBar onSearch={(city) => { setCity(city); fetchWeather(city); }} />
            {loading && <p>Loading...</p>}
            {error && <p className="error">{error}</p>}
            {weather && (
                <WeatherCard
                    weather={weather}
                />
            )}
        </div>
    );
};

export default App;